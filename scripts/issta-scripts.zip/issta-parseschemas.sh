#!/bin/bash
# Approx execution time: 20 seconds
# Note: Expect multiple "WARNING: Ignored statement 'CREATE INDEX..." lines to be produced

# Parse all of the schemas not already in parsedcasestudy
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava ArtistSimilarity Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava ArtistTerm Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava FACAData1997Repaired Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava Flav_R03_1Repaired Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava GeoMetadb Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava H1EFileFY2007Repaired Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava IsoFlav_R2Repaired Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava Mxm Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava SongTrackMetadata Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava StackOverflow Postgres
java -cp build:lib/* org.schemaanalyst.tool.SchemaSQLToJava WordNet Postgres

# Captialisation fix for GeoMetadb which ends up in file GeoMetaDB
mv src/parsedcasestudy/GeoMetaDB.java src/parsedcasestudy/GeoMetadb.java

# Compile all schemas
ant compile
