#!/bin/bash
# Approx execution time: 0 seconds

# Produces the ISSTA schema table, with sed formatting shivs
java -cp build:lib/* paper.issta2014.LatexSchemaStatsTable | sed -e 's|Constraints \\\\|Constraints \\\\ \\hline|' -e 's|\midrule|\hline|' -e 's|\(.*\bf Total.*\)|\1 \\hline|' -e 's|_|\\_|g' -e '/^$/d'
