#!/bin/bash

PIPEREPEATS='30'

CLASSPATH='lib/*:build/'
PIPELINE='AllOperatorsWithRemovers'
TODATABASE='false'
APPROACH='org.schemaanalyst.mutation.analysis.technique.FullSchemata'
TRIALS='3'

CASESTUDIES='ArtistSimilarity:ArtistTerm:BankAccount:BookTown:Cloc:CoffeeOrders:FACAData1997Repaired:Flav_R03_1Repaired:Flights:GeoMetadb:H1EFileFY2007Repaired:IsoFlav_R2Repaired:JWhoisServer:Mxm:NistDML181:NistDML182:NistDML183:NistWeather:NistXTS748:NistXTS749:RiskIt:SongTrackMetadata:StackOverflow:UnixUsage:WordNet'
IFS=':' read -ra CASESTUDY <<< "$CASESTUDIES"

DATAGENS='--datagenerator=AlternatingValueDefaults --satisfyrows=2 --negaterows=1'
DATAGENNAMES='AVMD_s2_n1'
IFS='|' read -ra DATAGEN <<< "$DATAGENS"
IFS='|' read -ra DATAGENNAME <<< "$DATAGENNAMES"

OPERATORS='CCNullifier,CCInExpressionRHSListExpressionElementR,CCRelationalExpressionOperatorE,FKCColumnPairA,FKCColumnPairR,FKCColumnPairE,PKCColumnA,PKCColumnR,PKCColumnE,NNCA,NNCR,UCColumnA,UCColumnR,UCColumnE|FKCColumnPairA,FKCColumnPairR,FKCColumnPairE,PKCColumnA,PKCColumnR,PKCColumnE,NNCA,NNCR,UCColumnA,UCColumnR,UCColumnE|CCNullifier,CCInExpressionRHSListExpressionElementR,CCRelationalExpressionOperatorE,PKCColumnA,PKCColumnR,PKCColumnE,NNCA,NNCR,UCColumnA,UCColumnR,UCColumnE|CCNullifier,CCInExpressionRHSListExpressionElementR,CCRelationalExpressionOperatorE,FKCColumnPairA,FKCColumnPairR,FKCColumnPairE,NNCA,NNCR,UCColumnA,UCColumnR,UCColumnE|CCNullifier,CCInExpressionRHSListExpressionElementR,CCRelationalExpressionOperatorE,FKCColumnPairA,FKCColumnPairR,FKCColumnPairE,PKCColumnA,PKCColumnR,PKCColumnE,UCColumnA,UCColumnR,UCColumnE|CCNullifier,CCInExpressionRHSListExpressionElementR,CCRelationalExpressionOperatorE,FKCColumnPairA,FKCColumnPairR,FKCColumnPairE,PKCColumnA,PKCColumnR,PKCColumnE|CCNullifier,CCInExpressionRHSListExpressionElementR,CCRelationalExpressionOperatorE,FKCColumnPairR,FKCColumnPairE,PKCColumnR,PKCColumnE,NNCR,UCColumnR,UCColumnE|CCRelationalExpressionOperatorE,FKCColumnPairA,FKCColumnPairE,PKCColumnA,PKCColumnE,NNCA,UCColumnA,UCColumnE|CCNullifier,CCInExpressionRHSListExpressionElementR,FKCColumnPairA,FKCColumnPairR,PKCColumnA,PKCColumnR,NNCA,NNCR,UCColumnA,UCColumnR'
OPERATORNAMES='Base|NoCC|NoFK|NoPK|NoNN|NoUC|NoA|NoR|NoE'
IFS='|' read -ra OPERATOR <<< "$OPERATORS"
IFS='|' read -ra OPERATORNAME <<< "$OPERATORNAMES"

PIPELINES='ProgrammaticDBMSRemovers'
REPEATEDPIPELINES='ProgrammaticDBMSRemovers50|ProgrammaticDBMSRemovers25|ProgrammaticDBMSRemovers10'
IFS='|' read -ra PIPELINE <<< "$PIPELINES"
IFS='|' read -ra REPEATEDPIPELINE <<< "$REPEATEDPIPELINES"

# For every non-repeated pipeline
for p in "${PIPELINE[@]}"; do
	# For every operator group
	for index in "${!OPERATOR[@]}"; do
		o=${OPERATOR[$index]}
		oname=${OPERATORNAME[$index]}

		# For every data generator
		for dindex in "${!DATAGEN[@]}"; do
			d=${DATAGEN[$dindex]}
			dname=${DATAGENNAME[$dindex]}

			# For every case study
			for c in "${CASESTUDY[@]}"; do
				# Generate once
				java -Xmx3G -cp $CLASSPATH org.schemaanalyst.mutation.analysis.util.GenerateResultsFromGenerator parsedcasestudy.$c $d

				# Test multiple times
				for (( t=1; t<=$TRIALS; t++ )) do
						java -Xmx3G -cp $CLASSPATH $APPROACH parsedcasestudy.$c $t '--mutationPipeline='$p:$o --resultsToOneFile
				done	
			done

			cat results/mutationanalysis.dat | sed -e '2,$s|$|',$p,$oname,$dname'|' > issta/$p-$oname-$dname
			rm -r results
		done
	done
done

# For every repeated pipeline
for (( r=1; r<=$PIPEREPEATS; r++ )) do
	for p in "${REPEATEDPIPELINE[@]}"; do
		# For every operator group
		for index in "${!OPERATOR[@]}"; do
			o=${OPERATOR[$index]}
			oname=${OPERATORNAME[$index]}

			# For every data generator
			for dindex in "${!DATAGEN[@]}"; do
				d=${DATAGEN[$dindex]}
				dname=${DATAGENNAME[$dindex]}

				# For every case study
				for c in "${CASESTUDY[@]}"; do
					# Generate once
					java -Xmx3G -cp $CLASSPATH org.schemaanalyst.mutation.analysis.util.GenerateResultsFromGenerator parsedcasestudy.$c $d

					# Test multiple times
					for (( t=1; t<=$TRIALS; t++ )) do
							java -Xmx3G -cp $CLASSPATH $APPROACH parsedcasestudy.$c $t '--mutationPipeline='$p:$o --resultsToOneFile
					done	
				done

				cat results/mutationanalysis.dat | sed -e '2,$s|$|',$p,$oname,$dname,$r'|' > issta/$p-$oname-$dname-$r
				rm -r results
			done
		done
	done
done
