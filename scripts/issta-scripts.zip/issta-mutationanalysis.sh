#!/bin/bash
# Approx execution time (3 trials): 12 minutes with Original, 8 minutes with FullSchemata

CLASSPATH='lib/*:build/'
PIPELINE='AllOperatorsWithRemovers'
TODATABASE='false'
APPROACH='org.schemaanalyst.mutation.analysis.technique.FullSchemata'
TRIALS='3'
CASESTUDIES='ArtistSimilarity:ArtistTerm:BankAccount:BookTown:Cloc:CoffeeOrders:FACAData1997Repaired:Flav_R03_1Repaired:Flights:GeoMetadb:H1EFileFY2007Repaired:IsoFlav_R2Repaired:JWhoisServer:Mxm:NistDML181:NistDML182:NistDML183:NistWeather:NistXTS748:NistXTS749:RiskIt:SongTrackMetadata:StackOverflow:UnixUsage:WordNet'

IFS=':' read -ra CASESTUDY <<< "$CASESTUDIES"

for c in "${CASESTUDY[@]}"; do
	# Generate once
	java -Xmx3G -cp $CLASSPATH org.schemaanalyst.mutation.analysis.util.GenerateResultsFromGenerator parsedcasestudy.$c

	# Test multiple times
	for (( t=1; t<=$TRIALS; t++ )) do
			java -Xmx3G -cp $CLASSPATH $APPROACH parsedcasestudy.$c $t '--mutationPipeline='$PIPELINE '--resultsToDatabase='$TODATABASE --resultsToOneFile
	done
done
