#!/bin/bash
# Approx execution time: 30 seconds
# Note: This is a sanity check, rather than a needed step - the 'experiment' script
# file takes care of data generation automatically

GENERATOR='org.schemaanalyst.mutation.analysis.util.GenerateResultsFromGenerator'
CLASSPATH='build:lib/*'

# Generate data for all schemas
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.ArtistSimilarity
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.ArtistTerm
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.BankAccount
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.BookTown
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.Cloc
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.CoffeeOrders
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.FACAData1997Repaired
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.Flav_R03_1Repaired
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.Flights
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.GeoMetadb
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.H1EFileFY2007Repaired
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.IsoFlav_R2Repaired
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.JWhoisServer
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.Mxm
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.NistDML181
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.NistDML182
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.NistDML183
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.NistWeather
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.NistXTS748
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.NistXTS749
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.RiskIt
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.SongTrackMetadata
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.StackOverflow
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.UnixUsage
java -Xmx3G -cp $CLASSPATH $GENERATOR parsedcasestudy.WordNet
